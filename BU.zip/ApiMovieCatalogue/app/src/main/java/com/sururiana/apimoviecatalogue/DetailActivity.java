package com.sururiana.apimoviecatalogue;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.github.ivbaranov.mfb.MaterialFavoriteButton;
import com.squareup.picasso.Picasso;
import com.sururiana.apimoviecatalogue.api.MoviesRepository;
import com.sururiana.apimoviecatalogue.api.OnGetDetailMovie;
import com.sururiana.apimoviecatalogue.data.MovieHelper;
import com.sururiana.apimoviecatalogue.model.Movie;
import com.sururiana.apimoviecatalogue.model.Tv;

public class DetailActivity extends AppCompatActivity implements View.OnClickListener{
    public static final String EXTRA_MOVIE = "extra_movie";
    public static final String EXTRA_TV = "extra_tv";
    public int movieId;
    ImageView thumnail;
    TextView txtTitle, txtDescription, txtRating, txt_release;
    String poster, rating;

    private MovieHelper movieHelper;
    private MoviesRepository moviesRepository;
    MaterialFavoriteButton favoriteButton, deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        movieHelper = MovieHelper.getInstance(getApplicationContext());
        movieHelper.open();
        setContentView(R.layout.activity_detail);
        favoriteButton = findViewById(R.id.btnFav);
        favoriteButton.setOnClickListener(this);
        deleteButton = findViewById(R.id.btnDel);
        deleteButton.setOnClickListener(this);
        getMovie();
    }

    private void getMovie() {
        final ProgressBar progressBar = findViewById(R.id.progressBar);
        Movie selectedMovie = getIntent().getParcelableExtra(EXTRA_MOVIE);
        movieId = selectedMovie.getId();
        moviesRepository = MoviesRepository.getInstance();
        moviesRepository.getMovie(movieId, new OnGetDetailMovie() {
            @Override
            public void onSuccess(Movie movie) {

                poster = movie.getPosterPath();
                thumnail = findViewById(R.id.img_object);

                txtTitle = findViewById(R.id.text_movie);
                txtTitle.setText(movie.getTitle());

                rating = Double.toString(movie.getVoteAverage());
                txtRating = findViewById(R.id.score_object);
                txtRating.setText(rating);

                txtDescription = findViewById(R.id.text_description);
                txtDescription.setText(movie.getOverview());

                txt_release = findViewById(R.id.text_release);
                txt_release.setText(movie.getReleaseDate());

                if (!isFinishing()) {
                    Picasso.get().load(poster).placeholder(R.drawable.load).into(thumnail);
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onError() {
                showError();
            }
        });
    }

    private void showError() {
        Toast.makeText(DetailActivity.this, "Please check your internet connection.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnFav) {
            Movie selectedMovie = getIntent().getParcelableExtra(EXTRA_MOVIE);
            String toastFav = "Add to favorite";
            String toastFavFail = "Failed";
            long result = movieHelper.insertMovie(selectedMovie);
            if (result > 0) {
                favoriteButton.setVisibility(View.GONE);
                deleteButton.setVisibility(View.VISIBLE);
                Toast.makeText(DetailActivity.this, toastFav, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DetailActivity.this, toastFavFail, Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.btnDel) {
            Movie selectedMovie = getIntent().getParcelableExtra(EXTRA_MOVIE);
            String toastDel = "Delete";
            movieHelper.deleteMovie(selectedMovie.getId());
            Toast.makeText(DetailActivity.this, toastDel, Toast.LENGTH_SHORT).show();
            favoriteButton.setVisibility(View.VISIBLE);
            deleteButton.setVisibility(View.GONE);
        }
    }
}
