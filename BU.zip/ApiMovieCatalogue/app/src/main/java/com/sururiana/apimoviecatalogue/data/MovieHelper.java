package com.sururiana.apimoviecatalogue.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.sururiana.apimoviecatalogue.model.Movie;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;
import static com.sururiana.apimoviecatalogue.data.FavoriteContract.FavoriteMovie.COLUMN_MOVIEID;
import static com.sururiana.apimoviecatalogue.data.FavoriteContract.FavoriteMovie.COLUMN_OVERVIEW;
import static com.sururiana.apimoviecatalogue.data.FavoriteContract.FavoriteMovie.COLUMN_POSTER_PATH;
import static com.sururiana.apimoviecatalogue.data.FavoriteContract.FavoriteMovie.COLUMN_RELEASE;
import static com.sururiana.apimoviecatalogue.data.FavoriteContract.FavoriteMovie.COLUMN_TITLE;
import static com.sururiana.apimoviecatalogue.data.FavoriteContract.FavoriteMovie.COLUMN_USERRATING;
import static com.sururiana.apimoviecatalogue.data.FavoriteContract.FavoriteMovie.TABLE_NAME;

public class MovieHelper {
    private static final String DATABASE_TABLE = TABLE_NAME;
    private static FavoriteDBHelper dataBaseHelper;
    private static MovieHelper INSTANCE;
    private static SQLiteDatabase database;

    private MovieHelper(Context context) {
        dataBaseHelper = new FavoriteDBHelper(context);
    }

    public static MovieHelper getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SQLiteOpenHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new MovieHelper(context);
                }
            }
        }
        return INSTANCE;
    }

    public void open() throws SQLException {
        database = dataBaseHelper.getWritableDatabase();
    }

    public void close() {
        dataBaseHelper.close();
        if (database.isOpen())
            database.close();
    }

    public ArrayList<Movie> getAllMovie() {
        ArrayList<Movie> arrayList = new ArrayList<>();
        Cursor cursor = database.query(DATABASE_TABLE, null,
                null,
                null,
                null,
                null,
                _ID + " ASC",
                null);
        cursor.moveToFirst();
        Movie movie;
        if (cursor.getCount() > 0) {
            do {
                movie = new Movie();
                movie.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_MOVIEID))));
                movie.setTitle(cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)));
                movie.setVoteAverage(Double.parseDouble(cursor.getString(cursor.getColumnIndex(COLUMN_USERRATING))));
                movie.setPosterPath(cursor.getString(cursor.getColumnIndex(COLUMN_POSTER_PATH)));
                movie.setOverview(cursor.getString(cursor.getColumnIndex(COLUMN_OVERVIEW)));
                movie.setReleaseDate(cursor.getString(cursor.getColumnIndex(COLUMN_RELEASE)));

                arrayList.add(movie);

                cursor.moveToNext();

            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return arrayList;
    }

    public long insertMovie(Movie movie) {
        ContentValues args = new ContentValues();
        args.put(COLUMN_MOVIEID, movie.getId());
        args.put(COLUMN_TITLE, movie.getTitle());
        args.put(COLUMN_USERRATING, movie.getVoteAverage());
        args.put(COLUMN_POSTER_PATH, movie.getPosterPath());
        args.put(COLUMN_OVERVIEW, movie.getOverview());
        args.put(COLUMN_RELEASE, movie.getReleaseDate());
        return database.insert(DATABASE_TABLE, null, args);
    }

    public void deleteMovie(int id) {
        database = dataBaseHelper.getWritableDatabase();
        database.delete(TABLE_NAME, COLUMN_MOVIEID + "=" + id, null);
    }

    public Cursor queryById(String id) {
        return database.query(DATABASE_TABLE
                , null
                , _ID + " = ?"
                , new String[]{id}
                , null
                , null
                , null
                , null);
    }
}
