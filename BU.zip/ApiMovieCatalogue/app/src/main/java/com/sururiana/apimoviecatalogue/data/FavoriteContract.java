package com.sururiana.apimoviecatalogue.data;

import android.provider.BaseColumns;

class FavoriteContract {

    static final class FavoriteMovie implements BaseColumns {

        static final String TABLE_NAME = "favorite_movie";
        static final String COLUMN_MOVIEID = "movieid";
        static final String COLUMN_TITLE = "title";
        static final String COLUMN_USERRATING = "userrating";
        static final String COLUMN_POSTER_PATH = "posterpath";
        static final String COLUMN_OVERVIEW = "overview";
        static final String COLUMN_RELEASE = "realise";
    }

    static final class FavoriteTvShow implements BaseColumns {

        static final String TABLE_NAME = "favorite_tv";
        static final String COLUMN_MOVIEID = "movieid";
        static final String COLUMN_TITLE = "title";
        static final String COLUMN_RELEASE = "release";
        static final String COLUMN_USERRATING = "userating";
        static final String COLUMN_POSTER_PATH = "posterpath";
        static final String COLUMN_OVERVIEW = "overview";
    }
}
